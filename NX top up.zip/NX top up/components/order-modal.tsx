'use client'

import { useState } from 'react'
import { X, Check, Diamond, AlertCircle, Zap, Gift } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import Image from 'next/image'
import type { Game } from '@/app/page'

interface OrderModalProps {
  game: Game | null
  isOpen: boolean
  onClose: () => void
}

export function OrderModal({ game, isOpen, onClose }: OrderModalProps) {
  const [playerId, setPlayerId] = useState('')
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null)
  const [step, setStep] = useState(1)

  if (!isOpen || !game) return null

  const handleContinue = () => {
    if (step === 1 && playerId.trim()) {
      setStep(2)
    } else if (step === 2 && selectedPackage !== null) {
      setStep(3)
    }
  }

  const handleBack = () => {
    if (step > 1) setStep(step - 1)
  }

  const resetAndClose = () => {
    setPlayerId('')
    setSelectedPackage(null)
    setStep(1)
    onClose()
  }

  const selectedPkg = selectedPackage !== null ? game.packages[selectedPackage] : null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={resetAndClose}
      />
      
      {/* Modal */}
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto glass-strong rounded-3xl border border-[#8B5CF6]/30 animate-fade-in-up">
        {/* Close button */}
        <button
          onClick={resetAndClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full glass hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5 text-gray-400" />
        </button>

        {/* Header */}
        <div className="relative h-32 md:h-40 overflow-hidden rounded-t-3xl">
          <Image
            src={game.image}
            alt={game.name}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E11] via-[#0B0E11]/70 to-transparent" />
          <div className="absolute bottom-4 left-6 right-6">
            <h2 className="font-[family-name:var(--font-orbitron)] text-2xl md:text-3xl font-bold text-white">
              {game.name}
            </h2>
            <p className="text-gray-400 font-[family-name:var(--font-rajdhani)]">
              {game.currency} Top-Up
            </p>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-4 border-b border-white/10">
          <div className="flex items-center justify-between">
            {['Player ID', 'Select Package', 'Payment'].map((label, index) => (
              <div key={label} className="flex items-center">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center font-[family-name:var(--font-orbitron)] text-sm font-bold
                  ${step > index + 1 
                    ? 'bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] text-white' 
                    : step === index + 1 
                      ? 'bg-[#8B5CF6] text-white' 
                      : 'bg-white/10 text-gray-500'
                  }
                `}>
                  {step > index + 1 ? <Check className="w-4 h-4" /> : index + 1}
                </div>
                <span className={`hidden sm:block ml-2 text-sm font-[family-name:var(--font-rajdhani)] ${
                  step >= index + 1 ? 'text-white' : 'text-gray-500'
                }`}>
                  {label}
                </span>
                {index < 2 && (
                  <div className={`hidden sm:block w-12 md:w-20 h-0.5 mx-2 ${
                    step > index + 1 ? 'bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF]' : 'bg-white/10'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Step 1: Player ID */}
          {step === 1 && (
            <div className="space-y-6 animate-fade-in-up">
              <div className="space-y-2">
                <label className="text-white font-[family-name:var(--font-rajdhani)] font-semibold text-lg">
                  Enter Your Player ID
                </label>
                <p className="text-gray-400 text-sm font-[family-name:var(--font-rajdhani)]">
                  Find your Player ID in the game settings
                </p>
              </div>
              <Input
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
                placeholder="Enter Player ID (e.g., 123456789)"
                className="h-14 bg-white/5 border-white/10 focus:border-[#8B5CF6] text-white placeholder:text-gray-500 font-[family-name:var(--font-rajdhani)] text-lg rounded-xl"
              />
              <div className="flex items-start gap-3 p-4 rounded-xl bg-[#8B5CF6]/10 border border-[#8B5CF6]/30">
                <AlertCircle className="w-5 h-5 text-[#8B5CF6] flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300 font-[family-name:var(--font-rajdhani)]">
                  Please double-check your Player ID before proceeding. Incorrect IDs may result in delayed or failed transactions.
                </p>
              </div>
            </div>
          )}

          {/* Step 2: Select Package */}
          {step === 2 && (
            <div className="space-y-6 animate-fade-in-up">
              <div className="space-y-2">
                <label className="text-white font-[family-name:var(--font-rajdhani)] font-semibold text-lg">
                  Select {game.currency} Package
                </label>
                <p className="text-gray-400 text-sm font-[family-name:var(--font-rajdhani)]">
                  Player ID: <span className="text-[#00D4FF]">{playerId}</span>
                </p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {game.packages.map((pkg, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedPackage(index)}
                    className={`relative p-4 rounded-xl border transition-all duration-300 text-left ${
                      selectedPackage === index
                        ? 'bg-gradient-to-br from-[#8B5CF6]/20 to-[#00D4FF]/20 border-[#8B5CF6] neon-border'
                        : 'bg-white/5 border-white/10 hover:border-[#8B5CF6]/50'
                    }`}
                  >
                    {pkg.bonus && (
                      <div className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#FF006E] to-[#8B5CF6] text-white text-xs font-bold font-[family-name:var(--font-rajdhani)] flex items-center gap-1">
                        <Gift className="w-3 h-3" />
                        +{pkg.bonus}
                      </div>
                    )}
                    <div className="flex items-center gap-2 mb-2">
                      <Diamond className="w-5 h-5 text-[#00D4FF]" />
                      <span className="font-[family-name:var(--font-orbitron)] text-lg font-bold text-white">
                        {pkg.amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="font-[family-name:var(--font-rajdhani)] text-xl font-bold text-[#00D4FF]">
                      ৳{pkg.price.toLocaleString()}
                    </div>
                    {selectedPackage === index && (
                      <div className="absolute top-2 left-2">
                        <div className="w-5 h-5 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Payment Summary */}
          {step === 3 && selectedPkg && (
            <div className="space-y-6 animate-fade-in-up">
              <div className="space-y-4 p-6 rounded-2xl glass border border-white/10">
                <h3 className="font-[family-name:var(--font-orbitron)] text-lg font-bold text-white">
                  Order Summary
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400 font-[family-name:var(--font-rajdhani)]">Game</span>
                    <span className="text-white font-[family-name:var(--font-rajdhani)]">{game.name}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400 font-[family-name:var(--font-rajdhani)]">Player ID</span>
                    <span className="text-[#00D4FF] font-[family-name:var(--font-rajdhani)]">{playerId}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400 font-[family-name:var(--font-rajdhani)]">Package</span>
                    <span className="text-white font-[family-name:var(--font-rajdhani)]">
                      {selectedPkg.amount.toLocaleString()} {game.currency}
                      {selectedPkg.bonus && (
                        <span className="text-[#FF006E] ml-1">(+{selectedPkg.bonus} Bonus)</span>
                      )}
                    </span>
                  </div>
                  <div className="h-px bg-white/10" />
                  <div className="flex justify-between">
                    <span className="text-white font-[family-name:var(--font-rajdhani)] font-semibold">Total</span>
                    <span className="text-2xl font-[family-name:var(--font-orbitron)] font-bold text-[#00D4FF]">
                      ৳{selectedPkg.price.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-4">
                <h3 className="font-[family-name:var(--font-rajdhani)] font-semibold text-white">
                  Select Payment Method
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  {['bKash', 'Nagad', 'Rocket'].map((method) => (
                    <button
                      key={method}
                      className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[#8B5CF6]/50 transition-all flex flex-col items-center gap-2"
                    >
                      <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                        <span className="font-[family-name:var(--font-rajdhani)] font-bold text-[#00D4FF] text-xs">
                          {method[0]}
                        </span>
                      </div>
                      <span className="text-sm text-gray-300 font-[family-name:var(--font-rajdhani)]">
                        {method}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/10 flex gap-3">
          {step > 1 && (
            <Button
              variant="outline"
              onClick={handleBack}
              className="flex-1 h-12 border-white/20 text-white hover:bg-white/10 font-[family-name:var(--font-rajdhani)] rounded-xl"
            >
              Back
            </Button>
          )}
          <Button
            onClick={step === 3 ? resetAndClose : handleContinue}
            disabled={(step === 1 && !playerId.trim()) || (step === 2 && selectedPackage === null)}
            className="flex-1 h-12 bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] hover:from-[#7C3AED] hover:to-[#00B8E6] text-white font-[family-name:var(--font-rajdhani)] font-bold rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {step === 3 ? (
              <span className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Pay Now
              </span>
            ) : (
              'Continue'
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
