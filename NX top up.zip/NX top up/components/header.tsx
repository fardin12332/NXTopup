'use client'

import { useState } from 'react'
import { Menu, X, Zap, Search, User } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-strong">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2 group">
            <div className="relative">
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-gradient-to-br from-[#8B5CF6] to-[#00D4FF] flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300">
                <Zap className="w-5 h-5 md:w-6 md:h-6 text-white" />
              </div>
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-[#8B5CF6] to-[#00D4FF] blur-lg opacity-50 group-hover:opacity-75 transition-opacity" />
            </div>
            <span className="font-[family-name:var(--font-orbitron)] text-lg md:text-xl font-bold text-white">
              NX <span className="text-[#00D4FF]">TOP UP</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {['Games', 'How It Works', 'Pricing', 'Support'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                className="font-[family-name:var(--font-rajdhani)] text-sm font-medium text-gray-300 hover:text-[#00D4FF] transition-colors relative group"
              >
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] group-hover:w-full transition-all duration-300" />
              </a>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" size="icon" className="text-gray-300 hover:text-[#00D4FF] hover:bg-white/5">
              <Search className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-300 hover:text-[#00D4FF] hover:bg-white/5">
              <User className="w-5 h-5" />
            </Button>
            <Button className="bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] hover:from-[#7C3AED] hover:to-[#00B8E6] text-white font-[family-name:var(--font-rajdhani)] font-semibold px-6 rounded-full border-0 shadow-lg shadow-purple-500/25">
              Sign In
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-gray-300 hover:text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden glass-strong border-t border-white/10">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-4">
            {['Games', 'How It Works', 'Pricing', 'Support'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                className="font-[family-name:var(--font-rajdhani)] text-base font-medium text-gray-300 hover:text-[#00D4FF] transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <div className="flex gap-3 pt-4 border-t border-white/10">
              <Button variant="outline" className="flex-1 border-[#8B5CF6]/50 text-white hover:bg-[#8B5CF6]/20">
                <User className="w-4 h-4 mr-2" />
                Account
              </Button>
              <Button className="flex-1 bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] text-white">
                Sign In
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
