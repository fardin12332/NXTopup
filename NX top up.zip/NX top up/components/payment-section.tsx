'use client'

import { useEffect, useRef, useState } from 'react'
import { CreditCard, Shield, Zap, Clock, CheckCircle2 } from 'lucide-react'

const paymentMethods = [
  { name: 'bKash', color: '#E2136E', initial: 'b' },
  { name: 'Nagad', color: '#F6941C', initial: 'N' },
  { name: 'Rocket', color: '#8C3494', initial: 'R' },
  { name: 'Visa', color: '#1A1F71', initial: 'V' },
  { name: 'Mastercard', color: '#EB001B', initial: 'M' },
]

const features = [
  {
    icon: Zap,
    title: 'Instant Delivery',
    description: 'Get your diamonds in under 60 seconds',
    color: '#00D4FF',
  },
  {
    icon: Shield,
    title: '100% Secure',
    description: 'SSL encrypted payment gateway',
    color: '#8B5CF6',
  },
  {
    icon: Clock,
    title: '24/7 Support',
    description: 'Round the clock customer service',
    color: '#FF006E',
  },
  {
    icon: CheckCircle2,
    title: 'Best Prices',
    description: 'Competitive rates guaranteed',
    color: '#10B981',
  },
]

export function PaymentSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-20 md:py-32 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#8B5CF6]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-[#00D4FF]/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#00D4FF]/30">
            <CreditCard className="w-4 h-4 text-[#00D4FF]" />
            <span className="text-sm text-gray-300 font-[family-name:var(--font-rajdhani)]">
              Secure Payments
            </span>
          </div>
          <h2 className="font-[family-name:var(--font-orbitron)] text-3xl md:text-5xl font-bold text-white">
            Trusted <span className="text-[#8B5CF6]">Payment</span> Methods
          </h2>
          <p className="text-gray-400 font-[family-name:var(--font-rajdhani)] text-lg max-w-2xl mx-auto">
            Pay with your favorite local and international payment methods
          </p>
        </div>

        {/* Payment Methods */}
        <div 
          className={`flex flex-wrap justify-center gap-4 md:gap-6 mb-20 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {paymentMethods.map((method, index) => (
            <div
              key={method.name}
              className="group relative p-6 md:p-8 rounded-2xl glass border border-white/10 hover:border-[#8B5CF6]/50 transition-all duration-300 cursor-pointer"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div 
                className="w-16 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center text-white text-2xl md:text-3xl font-bold transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: method.color }}
              >
                {method.initial}
              </div>
              <p className="mt-3 text-center text-sm text-gray-300 font-[family-name:var(--font-rajdhani)] font-medium">
                {method.name}
              </p>
              {/* Hover glow */}
              <div 
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"
                style={{ 
                  boxShadow: `0 0 30px ${method.color}40`,
                }}
              />
            </div>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className={`p-6 rounded-2xl glass border border-white/10 hover:border-[${feature.color}]/50 transition-all duration-500 group ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${(index + 5) * 100}ms` }}
            >
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110"
                style={{ backgroundColor: `${feature.color}20` }}
              >
                <feature.icon className="w-6 h-6" style={{ color: feature.color }} />
              </div>
              <h3 className="font-[family-name:var(--font-orbitron)] text-lg font-bold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-400 text-sm font-[family-name:var(--font-rajdhani)]">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-6 text-gray-500 font-[family-name:var(--font-rajdhani)]">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#10B981]" />
            <span>SSL Secured</span>
          </div>
          <div className="w-px h-4 bg-gray-700" />
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#00D4FF]" />
            <span>Verified Merchant</span>
          </div>
          <div className="w-px h-4 bg-gray-700" />
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#8B5CF6]" />
            <span>Instant Processing</span>
          </div>
        </div>
      </div>
    </section>
  )
}
