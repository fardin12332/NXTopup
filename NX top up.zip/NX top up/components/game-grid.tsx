'use client'

import { useEffect, useRef, useState } from 'react'
import { Gamepad2, Star, TrendingUp } from 'lucide-react'
import Image from 'next/image'
import type { Game } from '@/app/page'

interface GameGridProps {
  games: Game[]
  onSelectGame: (game: Game) => void
}

export function GameGrid({ games, onSelectGame }: GameGridProps) {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const cardsRef = useRef<(HTMLDivElement | null)[]>([])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = parseInt(entry.target.getAttribute('data-index') || '0')
          if (entry.isIntersecting) {
            setVisibleCards((prev) => new Set([...prev, index]))
          }
        })
      },
      { threshold: 0.1, rootMargin: '50px' }
    )

    cardsRef.current.forEach((card) => {
      if (card) observer.observe(card)
    })

    return () => observer.disconnect()
  }, [])

  const popularBadges = ['free-fire', 'pubg']
  const newBadges = ['valorant']

  return (
    <section id="games" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#8B5CF6]/30">
            <Gamepad2 className="w-4 h-4 text-[#8B5CF6]" />
            <span className="text-sm text-gray-300 font-[family-name:var(--font-rajdhani)]">
              Select Your Game
            </span>
          </div>
          <h2 className="font-[family-name:var(--font-orbitron)] text-3xl md:text-5xl font-bold text-white">
            Popular <span className="text-[#00D4FF]">Games</span>
          </h2>
          <p className="text-gray-400 font-[family-name:var(--font-rajdhani)] text-lg max-w-2xl mx-auto">
            Choose from your favorite games and get instant top-up at the best prices
          </p>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {games.map((game, index) => (
            <div
              key={game.id}
              ref={(el) => { cardsRef.current[index] = el }}
              data-index={index}
              onClick={() => onSelectGame(game)}
              className={`group relative cursor-pointer transition-all duration-500 ${
                visibleCards.has(index) 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="relative aspect-[3/4] rounded-2xl overflow-hidden glass border border-white/10 group-hover:border-[#8B5CF6]/50 transition-all duration-300">
                {/* Game Image */}
                <Image
                  src={game.image}
                  alt={game.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E11] via-[#0B0E11]/50 to-transparent" />
                
                {/* Glow effect on hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#8B5CF6]/30 to-transparent" />
                  <div className="absolute inset-0 border-2 border-[#8B5CF6]/50 rounded-2xl neon-border" />
                </div>

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {popularBadges.includes(game.id) && (
                    <span className="px-3 py-1 rounded-full bg-gradient-to-r from-[#FF006E] to-[#8B5CF6] text-white text-xs font-bold font-[family-name:var(--font-rajdhani)] flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      HOT
                    </span>
                  )}
                  {newBadges.includes(game.id) && (
                    <span className="px-3 py-1 rounded-full bg-gradient-to-r from-[#00D4FF] to-[#8B5CF6] text-white text-xs font-bold font-[family-name:var(--font-rajdhani)] flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      NEW
                    </span>
                  )}
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
                  <h3 className="font-[family-name:var(--font-orbitron)] text-lg md:text-xl font-bold text-white mb-1 group-hover:text-[#00D4FF] transition-colors">
                    {game.name}
                  </h3>
                  <p className="text-gray-400 text-sm font-[family-name:var(--font-rajdhani)]">
                    {game.currency} Available
                  </p>
                  
                  {/* Price indicator */}
                  <div className="mt-3 flex items-center gap-2">
                    <span className="text-xs text-gray-500 font-[family-name:var(--font-rajdhani)]">Starting from</span>
                    <span className="text-[#00D4FF] font-[family-name:var(--font-orbitron)] font-bold">
                      ৳{game.packages[0].price}
                    </span>
                  </div>
                </div>

                {/* Hover CTA */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <div className="px-6 py-3 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] text-white font-[family-name:var(--font-rajdhani)] font-bold transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-lg shadow-purple-500/30">
                    Top Up Now
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* More games coming */}
        <div className="mt-12 text-center">
          <p className="text-gray-500 font-[family-name:var(--font-rajdhani)]">
            More games coming soon...{' '}
            <span className="text-[#8B5CF6] cursor-pointer hover:text-[#00D4FF] transition-colors">
              Request a game
            </span>
          </p>
        </div>
      </div>
    </section>
  )
}
