'use client'

import { useEffect, useState, useRef } from 'react'
import { Star, CheckCircle, Users, TrendingUp } from 'lucide-react'

// Sample transactions for the ticker
const recentTransactions = [
  { user: 'Rakib***', game: 'Free Fire', amount: '520 Diamonds', time: '2 min ago' },
  { user: 'Nisa***', game: 'PUBG', amount: '660 UC', time: '3 min ago' },
  { user: 'Tanvir***', game: 'Mobile Legends', amount: '344 Diamonds', time: '5 min ago' },
  { user: 'Sakib***', game: 'Free Fire', amount: '1060 Diamonds', time: '6 min ago' },
  { user: 'Faria***', game: 'Valorant', amount: '1000 VP', time: '8 min ago' },
  { user: 'Mamun***', game: 'PUBG', amount: '1800 UC', time: '10 min ago' },
  { user: 'Ayesha***', game: 'Free Fire', amount: '2180 Diamonds', time: '12 min ago' },
  { user: 'Rafi***', game: 'Mobile Legends', amount: '706 Diamonds', time: '15 min ago' },
]

const reviews = [
  {
    name: 'Arif Rahman',
    avatar: 'A',
    rating: 5,
    comment: 'Super fast delivery! Got my diamonds in 30 seconds. Best service ever!',
    game: 'Free Fire',
  },
  {
    name: 'Tamanna Islam',
    avatar: 'T',
    rating: 5,
    comment: 'Very reliable and secure. I have been using NX TOP UP for 2 years now.',
    game: 'PUBG Mobile',
  },
  {
    name: 'Mehedi Hasan',
    avatar: 'M',
    rating: 5,
    comment: 'Amazing prices and instant top-up. Customer support is also excellent!',
    game: 'Valorant',
  },
  {
    name: 'Sadia Akter',
    avatar: 'S',
    rating: 5,
    comment: 'The best top-up service in Bangladesh. No delays, no issues. Highly recommended!',
    game: 'Mobile Legends',
  },
]

const stats = [
  { icon: Users, value: '10M+', label: 'Happy Gamers' },
  { icon: CheckCircle, value: '50M+', label: 'Transactions' },
  { icon: TrendingUp, value: '99.9%', label: 'Success Rate' },
  { icon: Star, value: '4.9/5', label: 'User Rating' },
]

export function TrustSignals() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-20 md:py-32 relative overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Live Transactions Ticker */}
        <div className="mb-20">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#10B981]/30 mb-4">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#10B981] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#10B981]"></span>
              </span>
              <span className="text-sm text-gray-300 font-[family-name:var(--font-rajdhani)]">
                Live Transactions
              </span>
            </div>
            <h2 className="font-[family-name:var(--font-orbitron)] text-2xl md:text-3xl font-bold text-white">
              Recent <span className="text-[#10B981]">Successful</span> Top-Ups
            </h2>
          </div>

          {/* Ticker */}
          <div className="relative overflow-hidden">
            <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-[#0B0E11] to-transparent z-10" />
            <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-[#0B0E11] to-transparent z-10" />
            
            <div className="flex animate-scroll-left">
              {[...recentTransactions, ...recentTransactions].map((tx, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 mx-2 px-4 py-3 rounded-xl glass border border-white/10 flex items-center gap-3"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8B5CF6] to-[#00D4FF] flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-[family-name:var(--font-rajdhani)] font-semibold text-sm">
                      {tx.user}
                    </p>
                    <p className="text-gray-400 text-xs font-[family-name:var(--font-rajdhani)]">
                      {tx.game} • <span className="text-[#00D4FF]">{tx.amount}</span>
                    </p>
                  </div>
                  <span className="text-gray-500 text-xs font-[family-name:var(--font-rajdhani)]">
                    {tx.time}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div 
          className={`grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-20 transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className="text-center p-6 md:p-8 rounded-2xl glass border border-white/10 hover:border-[#8B5CF6]/30 transition-colors"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <stat.icon className="w-8 h-8 mx-auto mb-4 text-[#00D4FF]" />
              <p className="font-[family-name:var(--font-orbitron)] text-3xl md:text-4xl font-bold text-white mb-2">
                {stat.value}
              </p>
              <p className="text-gray-400 font-[family-name:var(--font-rajdhani)]">
                {stat.label}
              </p>
            </div>
          ))}
        </div>

        {/* Reviews */}
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="font-[family-name:var(--font-orbitron)] text-2xl md:text-3xl font-bold text-white mb-4">
              What <span className="text-[#8B5CF6]">Gamers</span> Say
            </h2>
            <div className="flex items-center justify-center gap-1 mb-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-[#F59E0B] text-[#F59E0B]" />
              ))}
            </div>
            <p className="text-gray-400 font-[family-name:var(--font-rajdhani)]">
              Based on 50,000+ reviews
            </p>
          </div>

          <div 
            className={`grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 transition-all duration-700 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            {reviews.map((review, index) => (
              <div
                key={index}
                className="p-6 rounded-2xl glass border border-white/10 hover:border-[#8B5CF6]/30 transition-all duration-300 group"
                style={{ transitionDelay: `${(index + 4) * 100}ms` }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#8B5CF6] to-[#00D4FF] flex items-center justify-center text-white font-bold">
                    {review.avatar}
                  </div>
                  <div>
                    <p className="text-white font-[family-name:var(--font-rajdhani)] font-semibold">
                      {review.name}
                    </p>
                    <p className="text-gray-500 text-sm font-[family-name:var(--font-rajdhani)]">
                      {review.game} Player
                    </p>
                  </div>
                </div>
                <div className="flex gap-0.5 mb-3">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#F59E0B] text-[#F59E0B]" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm font-[family-name:var(--font-rajdhani)] leading-relaxed">
                  {`"${review.comment}"`}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
