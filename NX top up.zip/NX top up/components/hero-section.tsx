'use client'

import { useEffect, useState, useRef } from 'react'
import { ArrowRight, Sparkles, Shield, Zap, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

interface HeroSectionProps {
  onGetStarted: () => void
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const stats = [
    { icon: Clock, value: '< 1 min', label: 'Delivery Time' },
    { icon: Shield, value: '100%', label: 'Secure' },
    { icon: Sparkles, value: '10M+', label: 'Transactions' },
  ]

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#8B5CF6]/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-[#00D4FF]/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div 
            className={`space-y-8 text-center lg:text-left transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
            }`}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-[#8B5CF6]/30 text-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00D4FF] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00D4FF]"></span>
              </span>
              <span className="text-gray-300 font-[family-name:var(--font-rajdhani)]">
                Trusted by <span className="text-[#00D4FF] font-semibold">10 Million+</span> Gamers
              </span>
            </div>

            {/* Headline */}
            <div className="space-y-4">
              <h1 className="font-[family-name:var(--font-orbitron)] text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight text-balance">
                <span className="text-white">INSTANT</span>
                <br />
                <span className="bg-gradient-to-r from-[#8B5CF6] via-[#00D4FF] to-[#8B5CF6] bg-clip-text text-transparent animate-text-glow bg-[length:200%_auto] animate-shimmer">
                  TOP-UP
                </span>
              </h1>
              <p className="font-[family-name:var(--font-rajdhani)] text-xl md:text-2xl text-gray-400 max-w-xl mx-auto lg:mx-0 text-pretty">
                Unbeatable Prices. Lightning Fast Delivery. Level Up Your Game Instantly.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={onGetStarted}
                size="lg"
                className="group relative bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] hover:from-[#7C3AED] hover:to-[#00B8E6] text-white font-[family-name:var(--font-rajdhani)] font-bold text-lg px-8 py-6 rounded-full border-0 shadow-2xl shadow-purple-500/30 overflow-hidden"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Get Diamonds Now
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-[#00D4FF] to-[#8B5CF6] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-[#8B5CF6]/50 text-white hover:bg-[#8B5CF6]/20 font-[family-name:var(--font-rajdhani)] font-semibold text-lg px-8 py-6 rounded-full backdrop-blur-sm"
              >
                How It Works
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8">
              {stats.map((stat, index) => (
                <div 
                  key={stat.label}
                  className="text-center p-4 rounded-2xl glass border border-white/5 hover:border-[#8B5CF6]/30 transition-colors"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <stat.icon className="w-6 h-6 mx-auto mb-2 text-[#00D4FF]" />
                  <p className="font-[family-name:var(--font-orbitron)] text-xl md:text-2xl font-bold text-white">
                    {stat.value}
                  </p>
                  <p className="font-[family-name:var(--font-rajdhani)] text-sm text-gray-400">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* 3D Character / Image */}
          <div 
            className={`relative transition-all duration-1000 delay-300 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}
          >
            <div className="relative aspect-square max-w-lg mx-auto">
              {/* Glow rings */}
              <div className="absolute inset-0 rounded-full border-2 border-[#8B5CF6]/20 animate-pulse" />
              <div className="absolute inset-4 rounded-full border-2 border-[#00D4FF]/20 animate-pulse" style={{ animationDelay: '0.5s' }} />
              <div className="absolute inset-8 rounded-full border-2 border-[#8B5CF6]/20 animate-pulse" style={{ animationDelay: '1s' }} />
              
              {/* Central character placeholder */}
              <div className="absolute inset-12 rounded-full glass border border-[#8B5CF6]/30 flex items-center justify-center overflow-hidden animate-float">
                <div className="relative w-full h-full">
                  <Image
                    src="/images/hero-character.jpg"
                    alt="Gaming Character"
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E11] via-transparent to-transparent" />
                </div>
              </div>

              {/* Floating elements */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full glass border border-[#00D4FF]/30 animate-float" style={{ animationDelay: '0.2s' }}>
                <span className="text-[#00D4FF] font-[family-name:var(--font-orbitron)] text-sm font-bold">+500 💎</span>
              </div>
              <div className="absolute bottom-1/4 left-0 px-4 py-2 rounded-full glass border border-[#8B5CF6]/30 animate-float" style={{ animationDelay: '0.4s' }}>
                <span className="text-[#8B5CF6] font-[family-name:var(--font-orbitron)] text-sm font-bold">INSTANT</span>
              </div>
              <div className="absolute top-1/3 right-0 px-4 py-2 rounded-full glass border border-[#00D4FF]/30 animate-float" style={{ animationDelay: '0.6s' }}>
                <span className="text-[#00D4FF] font-[family-name:var(--font-orbitron)] text-sm font-bold">SECURE</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-gray-500 text-sm font-[family-name:var(--font-rajdhani)]">Scroll to explore</span>
        <div className="w-6 h-10 rounded-full border-2 border-gray-600 flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-[#00D4FF] rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  )
}
