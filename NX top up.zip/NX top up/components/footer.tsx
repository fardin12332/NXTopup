'use client'

import { Zap, Facebook, Twitter, Instagram, Youtube, Send, Mail, Phone, MapPin } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

const footerLinks = {
  games: ['Free Fire', 'PUBG Mobile', 'Valorant', 'Mobile Legends', 'Call of Duty', 'Genshin Impact'],
  support: ['Help Center', 'FAQs', 'Contact Us', 'Live Chat', 'Report Issue', 'Refund Policy'],
  company: ['About Us', 'Careers', 'Blog', 'Press Kit', 'Partners', 'Affiliates'],
  legal: ['Terms of Service', 'Privacy Policy', 'Cookie Policy', 'Disclaimer'],
}

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'Youtube' },
]

export function Footer() {
  return (
    <footer className="relative pt-20 pb-8 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E11] via-[#0F1419] to-transparent" />
      
      {/* Top border glow */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#8B5CF6] to-transparent" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Newsletter */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <h3 className="font-[family-name:var(--font-orbitron)] text-2xl md:text-3xl font-bold text-white mb-4">
            Stay <span className="text-[#00D4FF]">Updated</span>
          </h3>
          <p className="text-gray-400 font-[family-name:var(--font-rajdhani)] mb-6">
            Subscribe to get exclusive offers and latest gaming news
          </p>
          <div className="flex gap-2">
            <Input
              type="email"
              placeholder="Enter your email"
              className="h-12 bg-white/5 border-white/10 focus:border-[#8B5CF6] text-white placeholder:text-gray-500 font-[family-name:var(--font-rajdhani)] rounded-xl flex-1"
            />
            <Button className="h-12 px-6 bg-gradient-to-r from-[#8B5CF6] to-[#00D4FF] hover:from-[#7C3AED] hover:to-[#00B8E6] rounded-xl">
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Main Footer Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 pb-12 border-b border-white/10">
          {/* Brand */}
          <div className="col-span-2 md:col-span-3 lg:col-span-1">
            <a href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#8B5CF6] to-[#00D4FF] flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="font-[family-name:var(--font-orbitron)] text-lg font-bold text-white">
                NX <span className="text-[#00D4FF]">TOP UP</span>
              </span>
            </a>
            <p className="text-gray-400 text-sm font-[family-name:var(--font-rajdhani)] mb-4 max-w-xs">
              Your trusted partner for instant game top-ups. Fast, secure, and reliable service since 2020.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-400">
                <Mail className="w-4 h-4 text-[#8B5CF6]" />
                <span className="font-[family-name:var(--font-rajdhani)]">support@nxtopup.com</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Phone className="w-4 h-4 text-[#8B5CF6]" />
                <span className="font-[family-name:var(--font-rajdhani)]">+880 1234-567890</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <MapPin className="w-4 h-4 text-[#8B5CF6]" />
                <span className="font-[family-name:var(--font-rajdhani)]">Dhaka, Bangladesh</span>
              </div>
            </div>
          </div>

          {/* Games */}
          <div>
            <h4 className="font-[family-name:var(--font-orbitron)] text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Games
            </h4>
            <ul className="space-y-2">
              {footerLinks.games.map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-[#00D4FF] transition-colors text-sm font-[family-name:var(--font-rajdhani)]">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-[family-name:var(--font-orbitron)] text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Support
            </h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-[#00D4FF] transition-colors text-sm font-[family-name:var(--font-rajdhani)]">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-[family-name:var(--font-orbitron)] text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Company
            </h4>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-[#00D4FF] transition-colors text-sm font-[family-name:var(--font-rajdhani)]">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-[family-name:var(--font-orbitron)] text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Legal
            </h4>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-[#00D4FF] transition-colors text-sm font-[family-name:var(--font-rajdhani)]">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm font-[family-name:var(--font-rajdhani)]">
            © 2024 NX TOP UP. All rights reserved.
          </p>
          
          {/* Social Links */}
          <div className="flex items-center gap-3">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                className="w-10 h-10 rounded-full glass border border-white/10 flex items-center justify-center text-gray-400 hover:text-[#00D4FF] hover:border-[#00D4FF]/50 transition-all"
                aria-label={social.label}
              >
                <social.icon className="w-5 h-5" />
              </a>
            ))}
          </div>

          {/* Payment badges */}
          <div className="flex items-center gap-2 text-gray-500 text-sm font-[family-name:var(--font-rajdhani)]">
            <span>We accept:</span>
            <div className="flex gap-1">
              {['bKash', 'Nagad', 'Visa'].map((method) => (
                <span key={method} className="px-2 py-1 rounded bg-white/5 text-xs">
                  {method}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
