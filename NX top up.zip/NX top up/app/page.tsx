'use client'

import { useState, useEffect, useRef } from 'react'
import { Header } from '@/components/header'
import { HeroSection } from '@/components/hero-section'
import { GameGrid } from '@/components/game-grid'
import { OrderModal } from '@/components/order-modal'
import { PaymentSection } from '@/components/payment-section'
import { TrustSignals } from '@/components/trust-signals'
import { Footer } from '@/components/footer'
import { NeonBackground } from '@/components/neon-background'

export type Game = {
  id: string
  name: string
  image: string
  currency: string
  packages: { amount: number; price: number; bonus?: number }[]
}

const games: Game[] = [
  {
    id: 'free-fire',
    name: 'Free Fire',
    image: '/images/free-fire.jpg',
    currency: 'Diamonds',
    packages: [
      { amount: 100, price: 85 },
      { amount: 310, price: 255, bonus: 10 },
      { amount: 520, price: 425, bonus: 20 },
      { amount: 1060, price: 850, bonus: 60 },
      { amount: 2180, price: 1700, bonus: 180 },
      { amount: 5600, price: 4250, bonus: 600 },
    ]
  },
  {
    id: 'pubg',
    name: 'PUBG Mobile',
    image: '/images/pubg.jpg',
    currency: 'UC',
    packages: [
      { amount: 60, price: 85 },
      { amount: 325, price: 425, bonus: 25 },
      { amount: 660, price: 850, bonus: 60 },
      { amount: 1800, price: 2125, bonus: 200 },
      { amount: 3850, price: 4250, bonus: 500 },
      { amount: 8100, price: 8500, bonus: 1100 },
    ]
  },
  {
    id: 'valorant',
    name: 'Valorant',
    image: '/images/valorant.jpg',
    currency: 'VP',
    packages: [
      { amount: 475, price: 425 },
      { amount: 1000, price: 850, bonus: 50 },
      { amount: 2050, price: 1700, bonus: 150 },
      { amount: 3650, price: 2975, bonus: 350 },
      { amount: 5350, price: 4250, bonus: 600 },
      { amount: 11000, price: 8500, bonus: 1500 },
    ]
  },
  {
    id: 'mobile-legends',
    name: 'Mobile Legends',
    image: '/images/mobile-legends.jpg',
    currency: 'Diamonds',
    packages: [
      { amount: 86, price: 170, bonus: 6 },
      { amount: 172, price: 340, bonus: 12 },
      { amount: 257, price: 510, bonus: 17 },
      { amount: 344, price: 680, bonus: 24 },
      { amount: 706, price: 1360, bonus: 56 },
      { amount: 2195, price: 4250, bonus: 195 },
    ]
  },
]

export default function Home() {
  const [selectedGame, setSelectedGame] = useState<Game | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const gameGridRef = useRef<HTMLDivElement>(null)

  const handleGameSelect = (game: Game) => {
    setSelectedGame(game)
    setIsModalOpen(true)
  }

  const scrollToGames = () => {
    gameGridRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <main className="relative min-h-screen bg-[#0B0E11]">
      <NeonBackground />
      <div className="relative z-10">
        <Header />
        <HeroSection onGetStarted={scrollToGames} />
        <div ref={gameGridRef}>
          <GameGrid games={games} onSelectGame={handleGameSelect} />
        </div>
        <PaymentSection />
        <TrustSignals />
        <Footer />
      </div>
      
      <OrderModal 
        game={selectedGame} 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </main>
  )
}
