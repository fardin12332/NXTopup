'use client'

import { useState } from 'react'
import { ArrowRight, Check } from 'lucide-react'

export function NewsletterSection() {
  const [email, setEmail] = useState('')
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      setEmail('')
    }
  }

  return (
    <section id="contact" className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-secondary/30 via-background to-background" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="reveal max-w-3xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <p className="text-sm font-sans tracking-[0.4em] text-primary/80 uppercase">
              Exclusive Access
            </p>
            <h2 className="text-4xl md:text-6xl font-light">
              Join the <span className="gold-gradient">Elite Circle</span>
            </h2>
            <p className="text-lg text-muted-foreground font-sans max-w-xl mx-auto leading-relaxed">
              Be the first to discover limited editions, private viewings, 
              and exclusive events reserved for our distinguished members.
            </p>
          </div>

          {/* Newsletter Form */}
          {isSubmitted ? (
            <div className="glass p-8 rounded-sm inline-flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <Check className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-light text-lg">Welcome to the Elite Circle</p>
                <p className="text-sm text-muted-foreground font-sans">
                  {"You'll"} receive our exclusive updates soon.
                </p>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <input
                type="email"
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 px-6 py-4 bg-secondary/50 border border-border/50 rounded-sm text-foreground font-sans placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
              />
              <button
                type="submit"
                className="group relative inline-flex items-center justify-center px-8 py-4 overflow-hidden rounded-sm"
              >
                <span className="absolute inset-0 bg-gradient-to-r from-primary via-gold-light to-primary bg-[length:200%_100%] animate-shimmer" />
                <span className="relative flex items-center gap-2 text-sm font-sans tracking-widest text-primary-foreground uppercase">
                  Subscribe
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </span>
              </button>
            </form>
          )}

          <p className="text-xs text-muted-foreground font-sans">
            By subscribing, you agree to receive exclusive communications from TIMELESS ELITE.
            <br />
            We respect your privacy and will never share your information.
          </p>
        </div>
      </div>
    </section>
  )
}
