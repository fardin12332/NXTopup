'use client'

import { Quote } from 'lucide-react'

const testimonials = [
  {
    quote: "The Sovereign is not merely a watch—it's a statement of who I am. The craftsmanship is unparalleled, and every glance at my wrist reminds me of life's finest moments.",
    author: 'James Wellington',
    title: 'CEO, Wellington Enterprises',
  },
  {
    quote: "I've collected timepieces for three decades. TIMELESS ELITE represents the pinnacle of horological artistry. Each piece is a masterwork that transcends generations.",
    author: 'Dr. Elizabeth Chen',
    title: 'Art Curator, Metropolitan Museum',
  },
  {
    quote: "From the moment I received my Diplomat, I understood what true luxury means. The attention to detail is extraordinary—a true heirloom for my family.",
    author: 'Marcus Rothschild',
    title: 'Private Collector',
  },
]

export function TestimonialSection() {
  return (
    <section id="testimonials" className="py-32 relative">
      {/* Decorative line */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="reveal text-center mb-20 space-y-4">
          <p className="text-sm font-sans tracking-[0.4em] text-primary/80 uppercase">
            Distinguished Collectors
          </p>
          <h2 className="text-4xl md:text-6xl font-light">
            Words of <span className="gold-gradient">Distinction</span>
          </h2>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.author}
              className="reveal glass p-8 rounded-sm relative group hover:border-primary/40 transition-all duration-500"
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Quote Icon */}
              <div className="absolute -top-4 left-8">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                  <Quote className="w-4 h-4 text-primary-foreground" />
                </div>
              </div>

              <div className="pt-4 space-y-6">
                <p className="text-foreground/90 font-sans leading-relaxed italic">
                  "{testimonial.quote}"
                </p>

                <div className="pt-4 border-t border-border/30">
                  <p className="font-light text-lg">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground font-sans">
                    {testimonial.title}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
