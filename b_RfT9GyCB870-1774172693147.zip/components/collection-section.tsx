'use client'

import Image from 'next/image'
import { ArrowRight } from 'lucide-react'

const watches = [
  {
    id: 1,
    name: 'The Sovereign',
    collection: 'Heritage Collection',
    price: '$32,800',
    image: '/images/watch-1.jpg',
    description: 'Skeleton movement revealing master craftsmanship',
  },
  {
    id: 2,
    name: 'The Diplomat',
    collection: 'Classic Collection',
    price: '$24,500',
    image: '/images/watch-2.jpg',
    description: 'Timeless elegance for the modern gentleman',
  },
  {
    id: 3,
    name: 'The Voyager',
    collection: 'Sport Collection',
    price: '$28,900',
    image: '/images/watch-3.jpg',
    description: 'Precision chronograph for the adventurous soul',
  },
]

export function CollectionSection() {
  return (
    <section id="collection" className="py-32 relative">
      {/* Background accents */}
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
      
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="reveal text-center mb-20 space-y-4">
          <p className="text-sm font-sans tracking-[0.4em] text-primary/80 uppercase">
            Exclusive Timepieces
          </p>
          <h2 className="text-4xl md:text-6xl font-light">
            The <span className="gold-gradient">Collection</span>
          </h2>
          <p className="text-muted-foreground font-sans max-w-2xl mx-auto leading-relaxed">
            Each watch in our collection represents the pinnacle of horological excellence, 
            meticulously crafted to embody timeless sophistication.
          </p>
        </div>

        {/* Watch Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {watches.map((watch, index) => (
            <div
              key={watch.id}
              className="reveal group"
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="glass rounded-sm overflow-hidden hover:border-primary/40 transition-all duration-500">
                {/* Image Container */}
                <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-secondary/50 to-background">
                  <Image
                    src={watch.image}
                    alt={watch.name}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  {/* Overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-60" />
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div>
                    <p className="text-xs font-sans tracking-widest text-primary/70 uppercase mb-1">
                      {watch.collection}
                    </p>
                    <h3 className="text-2xl font-light">{watch.name}</h3>
                    <p className="text-sm text-muted-foreground font-sans mt-2">
                      {watch.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <span className="text-xl gold-gradient font-light">{watch.price}</span>
                    <button className="flex items-center gap-2 text-sm font-sans tracking-wider text-foreground/70 hover:text-primary transition-colors group/btn">
                      <span>View Details</span>
                      <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="reveal text-center mt-16">
          <a
            href="#"
            className="inline-flex items-center gap-3 text-sm font-sans tracking-widest text-primary hover:text-gold-light transition-colors uppercase group"
          >
            <span>View Full Collection</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-2" />
          </a>
        </div>
      </div>
    </section>
  )
}
