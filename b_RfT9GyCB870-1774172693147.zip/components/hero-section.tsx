'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { ChevronDown } from 'lucide-react'

export function HeroSection() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background to-secondary/30" />
      
      {/* Decorative elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/3 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen pt-24 pb-12">
          {/* Text Content */}
          <div className={`space-y-8 transition-all duration-1000 delay-300 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="space-y-2">
              <p className="text-sm font-sans tracking-[0.4em] text-primary/80 uppercase">
                Masterpiece Collection 2026
              </p>
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-light leading-[0.9] text-balance">
                <span className="block">Creation</span>
                <span className="block">Without</span>
                <span className="gold-gradient">Limitation</span>
              </h1>
            </div>
            
            <p className="text-lg md:text-xl font-sans text-muted-foreground max-w-md leading-relaxed">
              Every timepiece is a testament to generations of craftsmanship, 
              designed for those who understand that true luxury transcends time.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="#collection"
                className="group relative inline-flex items-center justify-center px-8 py-4 overflow-hidden rounded-sm"
              >
                <span className="absolute inset-0 bg-gradient-to-r from-primary via-gold-light to-primary bg-[length:200%_100%] animate-shimmer" />
                <span className="relative text-sm font-sans tracking-widest text-primary-foreground uppercase">
                  Explore Collection
                </span>
              </a>
              <a
                href="#craft"
                className="inline-flex items-center justify-center px-8 py-4 border border-primary/30 rounded-sm text-sm font-sans tracking-widest text-foreground/80 uppercase hover:bg-primary/10 hover:border-primary transition-all duration-300"
              >
                Our Craft
              </a>
            </div>
          </div>

          {/* Hero Watch Image */}
          <div className={`relative flex items-center justify-center transition-all duration-1000 delay-500 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="relative w-full max-w-lg aspect-square animate-float">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-radial from-primary/20 via-transparent to-transparent rounded-full blur-2xl" />
              
              <Image
                src="/images/hero-watch.jpg"
                alt="TIMELESS ELITE Signature Timepiece"
                fill
                className="object-contain drop-shadow-2xl"
                priority
              />
            </div>
            
            {/* Floating badge */}
            <div className="absolute bottom-10 right-0 glass px-6 py-4 rounded-sm">
              <p className="text-xs font-sans tracking-widest text-primary/80 uppercase">Starting From</p>
              <p className="text-2xl font-light gold-gradient">$24,500</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 transition-all duration-1000 delay-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
        <span className="text-xs font-sans tracking-[0.3em] text-muted-foreground uppercase">
          Scroll to Reveal
        </span>
        <ChevronDown className="w-5 h-5 text-primary animate-bounce" />
      </div>
    </section>
  )
}
