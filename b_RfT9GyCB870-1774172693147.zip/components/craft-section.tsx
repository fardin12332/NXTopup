'use client'

import { Clock, Diamond, Award, Sparkles } from 'lucide-react'

const features = [
  {
    icon: Clock,
    title: 'Swiss Precision',
    description: 'Every movement is assembled by master horologists in our Swiss atelier, ensuring unparalleled accuracy.',
  },
  {
    icon: Diamond,
    title: 'Premium Materials',
    description: 'Only the finest materials grace our timepieces—18k gold, sapphire crystal, and hand-selected gemstones.',
  },
  {
    icon: Award,
    title: 'Limited Editions',
    description: 'Each collection is produced in limited quantities, ensuring exclusivity for discerning collectors.',
  },
  {
    icon: Sparkles,
    title: 'Lifetime Service',
    description: 'Our commitment extends beyond purchase with complimentary lifetime maintenance and care.',
  },
]

export function CraftSection() {
  return (
    <section id="craft" className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/20 via-background to-background" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="reveal space-y-4">
              <p className="text-sm font-sans tracking-[0.4em] text-primary/80 uppercase">
                The Art of Timekeeping
              </p>
              <h2 className="text-4xl md:text-6xl font-light leading-tight">
                Crafted for <br />
                <span className="gold-gradient">Eternity</span>
              </h2>
              <p className="text-lg text-muted-foreground font-sans leading-relaxed max-w-lg">
                Since 1892, TIMELESS ELITE has defined luxury watchmaking through 
                an unwavering commitment to excellence. Our master craftsmen dedicate 
                over 2,000 hours to each timepiece, ensuring every detail reflects 
                our legacy of perfection.
              </p>
            </div>

            {/* Stats */}
            <div className="reveal grid grid-cols-3 gap-8 pt-8 border-t border-border/30">
              <div className="space-y-1">
                <p className="text-3xl md:text-4xl font-light gold-gradient">130+</p>
                <p className="text-sm font-sans text-muted-foreground">Years of Excellence</p>
              </div>
              <div className="space-y-1">
                <p className="text-3xl md:text-4xl font-light gold-gradient">2,000</p>
                <p className="text-sm font-sans text-muted-foreground">Hours per Watch</p>
              </div>
              <div className="space-y-1">
                <p className="text-3xl md:text-4xl font-light gold-gradient">47</p>
                <p className="text-sm font-sans text-muted-foreground">Master Artisans</p>
              </div>
            </div>
          </div>

          {/* Right - Feature Cards */}
          <div className="grid sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="reveal glass p-6 rounded-sm hover:border-primary/40 transition-all duration-500 group"
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-light mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground font-sans leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
