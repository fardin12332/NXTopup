'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { Navigation } from '@/components/navigation'
import { HeroSection } from '@/components/hero-section'
import { CollectionSection } from '@/components/collection-section'
import { CraftSection } from '@/components/craft-section'
import { TestimonialSection } from '@/components/testimonial-section'
import { NewsletterSection } from '@/components/newsletter-section'
import { Footer } from '@/components/footer'

export default function Home() {
  useEffect(() => {
    const reveals = document.querySelectorAll('.reveal')
    
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible')
          }
        })
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    )

    reveals.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <main className="min-h-screen bg-background overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <CollectionSection />
      <CraftSection />
      <TestimonialSection />
      <NewsletterSection />
      <Footer />
    </main>
  )
}
